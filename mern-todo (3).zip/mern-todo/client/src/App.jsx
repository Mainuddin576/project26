import { useEffect, useState } from "react";
import "./App.css";

const API = "http://localhost:5000/api/todos";

export default function App() {
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState("");

  const load = async () => {
    const res = await fetch(API);
    setTodos(await res.json());
  };

  useEffect(() => {
    load();
  }, []);

  const addTodo = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    await fetch(API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    setText("");
    load();
  };

  const toggle = async (id) => {
    await fetch(`${API}/${id}`, { method: "PUT" });
    load();
  };

  const remove = async (id) => {
    await fetch(`${API}/${id}`, { method: "DELETE" });
    load();
  };

  return (
    <div className="container">
      <h1>MERN Todo</h1>
      <form onSubmit={addTodo}>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Add a task..."
        />
        <button type="submit">Add</button>
      </form>
      <ul>
        {todos.map((t) => (
          <li key={t._id}>
            <span className={t.done ? "done" : ""} onClick={() => toggle(t._id)}>
              {t.text}
            </span>
            <button className="del" onClick={() => remove(t._id)}>
              ✕
            </button>
          </li>
        ))}
      </ul>
      {todos.length === 0 && <p className="empty">No tasks yet.</p>}
    </div>
  );
}
