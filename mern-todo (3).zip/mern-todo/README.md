# MERN Todo

Simple MERN (MongoDB, Express, React, Node) todo app.

## Run

Start MongoDB locally first (or set `MONGO_URI` to a MongoDB Atlas URL).

### Backend
```
cd server
npm install
npm start
```
Runs on http://localhost:5000

### Frontend
```
cd client
npm install
npm run dev
```
Open http://localhost:5173
